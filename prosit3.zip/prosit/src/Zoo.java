import java.util.Arrays;
import java.util.Scanner;

public class Zoo {
    private Animal[] animals;

    private String name;
    private String city;
    private final int nbrCages=25;
    private int nbrAnimal;

    public int getNbrAnimal() {
        return nbrAnimal;
    }

    public void setNbrAnimal(int nbrAnimal) {
        this.nbrAnimal = nbrAnimal;
    }


    public Zoo() {
    }

    public Zoo(Animal[] animals, String name, String city) {
        this.animals = new Animal[nbrCages];
        this.name = name;
        this.city = city;
        nbrAnimal=0;
    }

    public Animal[] getAnimals() {
        return animals;
    }

    public void setAnimals(Animal[] animals) {
        this.animals = animals;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getNbrCages() {
        return nbrCages;
    }



    @Override
    public String toString() {
        return "Zoo{name='" + name + "', city='" + city + "', nbrCages=" + nbrCages + ", animals=" + java.util.Arrays.toString(animals) + "}";
    }

    public void displayZoo() {
        System.out.println("Nom du Zoo: " + name);
        System.out.println("Ville: " + city);
        System.out.println("Nbr de cages: " + nbrCages);
        for (Animal animal :animals){
            System.out.println("Nom animal " + animal.getName());
            System.out.println("famille " + animal.getFamily());
            System.out.println("age : " + animal.getAge());
            System.out.println("mam" + animal.isMammal());
        }
    }

    public boolean addAnimal(Animal animal) {
        if(searchAnimal(animal)==-1 && nbrAnimal<animals.length){
            animals[nbrAnimal]=animal;
            nbrAnimal++;
            return true;
        }
        else {
            System.out.println("nbr cage id full");
            return false;
        }
    }

    public int searchAnimal(Animal animal){
        int test =-1;
        int i =0;
        while (test==-1 && i<animals.length){
            if (animals[i]!=null &&animals[i].equals(animal)){
                test=i;
            }
            else {
                i++;
            }
        }
        return test;
    }
    public boolean removeAnimal(Animal animal){
        int index = searchAnimal(animal);
        if (index==-1){
            System.out.println("didnt found animal");
            return false;
        }
        for(int i =index;i<animals.length;i++){
            animals[i]=animals[i+1];
        }
        animals[nbrAnimal-1]=null;
        nbrAnimal--;
        System.out.println("Animal supprimé avec succès.");
        return true;
    }

    public  boolean isZooFull(){
        return nbrAnimal>=25;
    }
    public Zoo comparerZoo(Zoo z1, Zoo z2){
        if (z1.nbrAnimal > z2.nbrAnimal){
            return z1;
        }
        else if(z1.nbrAnimal < z2.nbrAnimal) {
            return z2;
        }
        else {return null;}
    }

}