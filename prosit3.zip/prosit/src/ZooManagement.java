import java.util.Scanner;

public class ZooManagement {
    private  int nbr_cages=20;
    private  String zooname = "my zoo";

    public void lire(){
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.print("Donner le nom du zoo : ");
            zooname = scanner.nextLine();
        } while (zooname.isEmpty() || !zooname.matches("[a-zA-Z]+"));

        do {
            System.out.println("donner le nombre de taille du  zoo : ");
            nbr_cages = scanner.nextInt();
        }while (nbr_cages<0);
    }



    public void afficher () {
        System.out.printf("%s comporte %d cages", zooname, nbr_cages ) ;
    }




    public static void main (String[] args) {
       /* Zoo zoo = new Zoo();
        zoo.remplirZoo();
        */
        Animal [] animals = new Animal[3];
        Animal animal1 = new Animal("aaa","lion",14 , true );
        Animal animal2 = new Animal("bbb","bata",14 , true );
        Animal animal3 = new Animal("ccc","aalouch",14 , true );
        Animal animal4 = new Animal("ccc","hwila",14 , true );
        Zoo zoo = new Zoo(animals,"cocobeach","bizerte");
        System.out.println("ajout du animal1 "+ zoo.addAnimal(animal1));
        System.out.println("ajout du animal2 "+ zoo.addAnimal(animal1));
        System.out.println("ajout du animal3 "+ zoo.addAnimal(animal3));
        System.out.println("ajout du animal3 "+ zoo.addAnimal(animal4));
        //System.out.println(zoo);
        zoo.displayZoo();
        //System.out.println("animal :"+zoo.searchAnimal(animal1));
        //System.out.println("animal"+zoo.searchAnimal(animal4));


            }

}

