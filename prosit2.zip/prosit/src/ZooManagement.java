import java.util.Scanner;

public class ZooManagement {
    private  int nbr_cages=20;
    private  String zooname = "my zoo";

    public void lire(){
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.print("Donner le nom du zoo : ");
            zooname = scanner.nextLine();
        } while (zooname.isEmpty() || !zooname.matches("[a-zA-Z]+"));

        do {
            System.out.println("donner le nombre de taille du  zoo : ");
            nbr_cages = scanner.nextInt();
        }while (nbr_cages<0);
    }



    public void afficher () {
        System.out.printf("%s comporte %d cages", zooname, nbr_cages ) ;
    }




    public static void main (String[] args) {
       /* Zoo zoo = new Zoo();
        zoo.remplirZoo();
        */
        Animal animal = new Animal("mam","lion",14 , true );
        Animal animals [] = {animal};
        Zoo zoo = new Zoo(animals,"cocobeach","bizerte",1);
        zoo.displayZoo();
        animal.displayAnimal();
    }

}

