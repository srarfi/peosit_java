import java.util.Arrays;
import java.util.Scanner;

public class Zoo {
    private Animal [] animals;

    private String name ;
    private String city ;
    private int nbrCages ;
    public Zoo() {}
    public Zoo(Animal[] animals, String name, String city, int nbrCages) {
        this.animals = new Animal[nbrCages] ;
        this.name = name;
        this.city = city;
        this.nbrCages = nbrCages;
    }
    public Animal[] getAnimals() {
        return animals;
    }

    public void setAnimals(Animal[] animals) {
        this.animals = animals;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getNbrCages() {
        return nbrCages;
    }

    public void setNbrCages(int nbrCages) {
        this.nbrCages = nbrCages;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "animals=" + Arrays.toString(animals) +
                ", name='" + name + '\'' +
                ", city='" + city + '\'' +
                ", nbrCages=" + nbrCages +
                '}';
    }


    /*public void remplirZoo(){
        Scanner scanner = new Scanner(System.in);
        Animal a = new Animal();

        do {
            System.out.print("Donner le nom du zoo : ");
            name = scanner.nextLine();
        } while (name.isEmpty() || !name.matches("[a-zA-Z]+"));

        do {
            System.out.print("Donner la citee du zoo : ");
            city = scanner.nextLine();
        } while (city.isEmpty() || !city.matches("[a-zA-Z]+"));

        do {
            System.out.println("donner le nombre de cage du zoo : ");
            nbrCages = scanner.nextInt();
        } while (nbrCages < 0);

        animals = new Animal[nbrCages];

        for ( int i= 0 ; i<nbrCages;i ++){
            System.out.println("Saisir les informations pour l'animal " + (i + 1) + ":");
            animals[i] = a.saisirAnimal();

        }
    }*/
    public void displayZoo(){
        System.out.println("Nom du Zoo: " + name);
        System.out.println("Ville: " + city);
        System.out.println("Nombre de cages: " + nbrCages);
        }
}
